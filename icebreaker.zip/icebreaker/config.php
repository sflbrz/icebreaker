<?php
$config = [
"memberId"=>"xxxxxx",
"token"=>"xxxxxx"
];